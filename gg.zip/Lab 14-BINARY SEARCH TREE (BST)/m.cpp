#include <iostream>
#include "bst.cpp"

using namespace std;

int main()
{
    BST<int>tree;
    tree.Insert(2);
    tree.Insert(3);
    tree.Insert(1);
    tree.Insert(1);
    tree.Insert(7);
    tree.Insert(7);
    tree.Insert(4);
    tree.Insert(0);
    tree.Insert(4);
    tree.Insert(2);
    tree.Reset(IN_ORDER);
    cout<<"IN Order";
    int value;
    for(int i=0;i<tree.Length();i++){
        tree.GetNext(value,IN_ORDER);
        cout<< value<< " ";
    }
    cout<<"after op";
    tree.Reset(IN_ORDER);
    tree.BuildOptimalTree();
    bool found;
    for(int i=0;i<tree.Length();i++){
        tree.GetNext(value,IN_ORDER);
        tree.Search(value,found);
        if(!found){
            tree.Insert(value);
        }
        cout<<value;

       
    }

}